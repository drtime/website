<?php

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <link rel="stylesheet" href="resformtijdelijk.css">
    <title>Reserveren Ballentent</title>

</head>

<body>

<header>

<div class="groenebalktop">
    <img src="https://i.gyazo.com/6c8c8a04980d98fde51fbaa9b4c7734c.png">
</div>

<div class="module">

        <div class="module-body">

            <div class="custom">
                <table border="0" cellpadding="0" cellspacing="0" width="970">
                    <tbody>
                    <tr>
                        <td>
                            <img height="122" src="http://www.deballentent.nl/images/Logo_Left.png" width="711"><img src="http://www.deballentent.nl/images/TripHeader.png" width="109" height="122" border="0"></td>
                        <td>
                            <a href="http://www.tripadvisor.nl/Restaurant_Review-g188632-d2284304-Reviews-De_Ballentent-Rotterdam_South_Holland_Province.html" target="_new"><img alt="Misset Horeca" border="0" height="122" id="Misset Horeca" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Misset Horeca','','http://www.deballentent.nl/images/Logo_Right_onta.png',1)" src="http://www.deballentent.nl/images/Logo_Right_offta.png" width="150"></a></td>

                    </tr>
                    </tbody>
                </table></div>
        </div>
    </div>

    <a href="/" id="logo"></a>
</div>

<div class="rodelijnen">
    <img src="http://www.deballentent.nl/images/TripHeader.png">
</div>

<div class="rodelijnen2">
    <img src="http://www.deballentent.nl/images/TripHeader.png">
</div>

<div class="rodelijnen3">
    <img src="http://www.deballentent.nl/images/TripHeader.png">
</div>

<div class="rodelijnen4">
    <img src="http://www.deballentent.nl/images/TripHeader.png">
</div>

<div class="rodelijnen5">
    <img src="http://www.deballentent.nl/images/TripHeader.png">
</div>

<div class="rodelijnen6">
    <img src="http://www.deballentent.nl/images/TripHeader.png">
</div>

<div class="rodelijnen7">
    <img src="http://www.deballentent.nl/images/TripHeader.png">
</div>

<div class="rodelijnen8">
    <img src="http://www.deballentent.nl/images/TripHeader.png">
</div>

<div class="rodelijnen9">
    <img src="http://www.deballentent.nl/images/TripHeader.png">
</div>

<div class="rodelijnen9">
    <img src="http://www.deballentent.nl/images/TripHeader.png">
</div>

<div class="rodelijnen10">
    <img src="http://www.deballentent.nl/images/TripHeader.png">
</div>

<div class="onlinereserveren">
    <img src="http://trixs.nl/wp-content/uploads/2014/05/reserveren.png">
</div>

</header>

<form action="ballententres.php" method="post" id="form_opgeven">

    <h3>RESERVEREN BIJ DE BALLENTENT</h3>
    <br>

    <h3>Uw gegevens</h3>

    <label>Voornaam*:</label>
    <input type="text" name="voornaam" placeholder=" Voornaam">
    <br>

    <label>Achternaam*:</label>
    <input type="text" name="achternaam" placeholder=" Achternaam">
    <br>

    <label>Adres:</label>
    <input type="text" name="adres" placeholder=" Straat 1">
    <br>

    <label>Postcode:</label>
    <input type="text" name="postcode" placeholder=" 1234 AB" class="hoofdletters">
    <br>

    <label>Woonplaats:</label>
    <input type="text" name="woonplaats" placeholder=" Plaatsnaam">
    <br>

    <label>Provincie:</label>
    <select name="provincie">
        <option disabled="disabled" selected="selected">Provincienaam</option>
        <optgroup label="-----">
            <option value="Drenthe"> Drenthe </option>
            <option value="Flevoland"> Flevoland </option>
            <option value="Friesland"> Friesland </option>
            <option value="Gelderland"> Gelderland </option>
            <option value="Groningen"> Groningen </option>
            <option value="Limburg"> Limburg </option>
            <option value="Noord-Brabant"> Noord-Brabant </option>
            <option value="Noord-Holland"> Noord-Holland </option>
            <option value="Overijssel"> Overijssel </option>
            <option value="Utrecht"> Utrecht </option>
            <option value="Zeeland"> Zeeland </option>
            <option value="Zuid-Holland"> Zuid-Holland </option>
        </optgroup>
        <optgroup label ="-----">
            <option value="Buitenland"> Buitenland </option>
        </optgroup>
    </select>
    <br>

    <label>Telefoonnummer*:</label>
    <input type="text" name="telefoon" placeholder=" 012-3456789">
    <br>

    <label>Emailadres*:</label>
    <input type="text" name="email" placeholder=" naam@voorbeeld.nl" >
    <br>

    <h3>Tafelwensen</h3>

    <label>Datum*:</label>
    <input type="date" name="datum">
    <br>

    <label>Tijd*:</label>
    <input type="time" name="tijd">
    <br>

    <label>Aantal personen*:</label>
    <input type="text" name="aantal" placeholder=" 10 personen bijvoorbeeld.">
    <br>

    <label>Voorkeur van zitplaats:</label>
    <input type="text" name="zitplaats" placeholder=" Coming soon...">
    <br>

    <h3>Overige informatie</h3>

    <label>Eventuele opmerkingen:</label>
    <textarea name="opmerkingen" placeholder=" Eventuele allergieën of dingen waar wij rekening mee moeten houden "></textarea>
    <br>
    <br>

    <button onclick="alertbox()">Reserveren</button>
    <script>
        function alertbox(){
            alert(" Als u een reservering heeft geplaatst betekent dat niet gelijk dat u ook \n terecht kunt bij de Ballentent. \n Voor bevestiging zal u moeten wachten op een mailtje of sms'je. \n Wilt u direct te woord gestaan worden? Neem dan telefonisch contact op!");
        }
    </script>

</form>

<!-- Trigger/Open The Modal -->
<button id="myBtn">Reserveren</button>

<!-- The Modal -->
<div id="myModal" class="modal">

    <!-- Modal content -->
    <div class="modal-content">
        <div class="modal-header">
            <span class="close">&times;</span>
            <h2>Reserveren bij Havenkroeg De Ballentent</h2>
        </div>
        <div class="modal-body">
            <p>Als u een reservering heeft geplaatst betekent dat niet gelijk dat u ook terecht kunt bij de Ballentent. </p>
            <p>Voor bevestiging zal u moeten wachten op een mailtje of sms'je.</p>
            <p>Wilt u direct te woord gestaan worden? Neem dan telefonisch contact op!</p>
        </div>
        <form action="ballententres.php" method="post" id="form_opgeven">
        <div class="modal-footer">
                <button onclick="">Reserveren</button>
        </div>
        </form>
    </div>

</div>

<script>
    var modal = document.getElementById('myModal');

    var btn = document.getElementById("myBtn");

    var span = document.getElementsByClassName("close")[0];

    btn.onclick = function() {
        modal.style.display = "block";
    }

    span.onclick = function() {
        modal.style.display = "none";
    }

    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>

</body>

</html>