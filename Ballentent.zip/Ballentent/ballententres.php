<?php

    $con = mysqli_connect("localhost", "root", "");

    if(!$con)
        {
            echo "Niet geconnect aan de server";
        }

    if(!mysqli_select_db($con, "test"))
        {
            echo "Database niet geselecteerd";
        }

    $voornaam = $_POST['voornaam'];
    $achternaam = $_POST['achternaam'];
    $adres = $_POST['adres'];
    $woonplaats = $_POST['woonplaats'];
    $postcode = $_POST['postcode'];
    $telefoon = $_POST['telefoon'];
    $email = $_POST['email'];
    $datum = $_POST['datum'];
    $tijd = $_POST['tijd'];
    $aantal = $_POST['aantal'];
    $zitplaats = $_POST['zitplaats'];
    $opmerkingen = $_POST['opmerkingen'];

    $sql = "INSERT INTO ballententreservering (Voornaam, Achternaam, Adres, Woonplaats, Postcode, Telefoon, Email, Datum, Tijd, Aantal, Zitplaats, Opmerking) VALUES('$voornaam', '$achternaam', '$adres', '$woonplaats', '$postcode', '$telefoon', '$email', '$datum', '$tijd' '$aantal', '$zitplaats', '$opmerkingen')";

?>

<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <link rel="stylesheet" href="resformtijdelijk.css">
    <title>Reserveren Ballentent</title>

</head>

<body>

<header>

    <div class="groenebalktop">
        <img src="https://i.gyazo.com/6c8c8a04980d98fde51fbaa9b4c7734c.png">
    </div>

    <div class="module">

        <div class="module-body">

            <div class="custom">
                <table border="0" cellpadding="0" cellspacing="0" width="970">
                    <tbody>
                    <tr>
                        <td>
                            <img height="122" src="http://www.deballentent.nl/images/Logo_Left.png" width="711"><img src="http://www.deballentent.nl/images/TripHeader.png" width="109" height="122" border="0"></td>
                        <td>
                            <a href="http://www.tripadvisor.nl/Restaurant_Review-g188632-d2284304-Reviews-De_Ballentent-Rotterdam_South_Holland_Province.html" target="_new"><img alt="Misset Horeca" border="0" height="122" id="Misset Horeca" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Misset Horeca','','http://www.deballentent.nl/images/Logo_Right_onta.png',1)" src="http://www.deballentent.nl/images/Logo_Right_offta.png" width="150"></a></td>

                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <a href="/" id="logo"></a>
    </div>

    <div class="rodelijnen">
        <img src="http://www.deballentent.nl/images/TripHeader.png">
    </div>

    <div class="rodelijnen2">
        <img src="http://www.deballentent.nl/images/TripHeader.png">
    </div>

    <div class="rodelijnen3">
        <img src="http://www.deballentent.nl/images/TripHeader.png">
    </div>

    <div class="rodelijnen4">
        <img src="http://www.deballentent.nl/images/TripHeader.png">
    </div>

    <div class="rodelijnen5">
        <img src="http://www.deballentent.nl/images/TripHeader.png">
    </div>

    <div class="rodelijnen6">
        <img src="http://www.deballentent.nl/images/TripHeader.png">
    </div>

    <div class="rodelijnen7">
        <img src="http://www.deballentent.nl/images/TripHeader.png">
    </div>

    <div class="rodelijnen8">
        <img src="http://www.deballentent.nl/images/TripHeader.png">
    </div>

    <div class="rodelijnen9">
        <img src="http://www.deballentent.nl/images/TripHeader.png">
    </div>

    <div class="rodelijnen9">
        <img src="http://www.deballentent.nl/images/TripHeader.png">
    </div>

    <div class="rodelijnen10">
        <img src="http://www.deballentent.nl/images/TripHeader.png">
    </div>

    <div class="onlinereserveren">
        <img src="http://trixs.nl/wp-content/uploads/2014/05/reserveren.png">
    </div>

</header>

<section class="container">
    <div class="row">
        <div class="col-sm-12">
            <h3>Ingevoerde gegevens</h3>
            <table>
                <tr>
                    <td>Voornaam:</td>
                    <td><?php echo "$voornaam" ?></td>
                </tr>
                <tr>
                    <td>Achternaam:</td>
                    <td><?php echo "$achternaam" ?></td>
                </tr>
                <tr>
                    <td>Adres:</td>
                    <td><?php echo "$adres" ?></td>
                </tr>
                <tr>
                    <td>Woonplaats:</td>
                    <td><?php echo "$woonplaats" ?></td>
                </tr>
                <tr>
                    <td>Postcode:</td>
                    <td><?php echo "$postcode" ?></td>
                </tr>
                <tr>
                    <td>Email:</td>
                    <td><?php echo "$email" ?></td>
                </tr>
                <tr>
                    <td>Telefoonnummer:</td>
                    <td><?php echo "$telefoon" ?></td>
                </tr>
                <tr>
                    <td>Datum:</td>
                    <td><?php echo "$datum" ?></td>
                </tr>
                <tr>
                    <td>Tijd:</td>
                    <td><?php echo "$tijd" ?></td>
                </tr>
                <tr>
                    <td>Aantal personen:</td>
                    <td><?php echo "$aantal" ?></td>
                </tr>
                <tr>
                    <td>Tafelzone:</td>
                    <td><?php echo "$zitplaats" ?></td>
                </tr>
                <tr>
                    <td>Opmerkingen:</td>
                    <td><?php echo "$opmerkingen" ?></td>
                </tr>

            </table>

            <br/>Bedankt voor uw reservering. De Ballentent zal zo spoedig mogelijk contact met u opnemen!
        </div>

    </div>
</section>

</body>

</html>

