<?php

$voornaam = $_POST['voornaam'];
$achternaam = $_POST['achternaam'];
$telefoon = $_POST['telefoon'];
$email = $_POST['email'];
$personen = $_POST['personen'];

mysqli_connect("localhost", "root", "");
mysqli_select_db("ballentent");

$select="insert into ballentent(voornaam, achternaam, telefoon, email, personen, zitplaats) values('".$voornaam."', '".$achternaam."', '".$telefoon."', '".$email."', '".$personen."')";
$sql=mysqli_query($select);

print '<script type="text/javascript">';
print 'alert("Uw reservering is geplaatst!")';
print '</script>';

mysqli_close();

?>