/* Initialisation pagePiling (screen scrolling) */
$(document).ready(function() {
    $('#pagepiling').pagepiling({
        verticalCentered: false,
        css3: false
    });
});






